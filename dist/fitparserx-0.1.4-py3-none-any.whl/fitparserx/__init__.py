# fitparserx/__init__.py
from .parser import FitParser

__version__ = "0.1.4"
